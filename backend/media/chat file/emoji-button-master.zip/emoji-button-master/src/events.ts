export const EMOJI = 'emoji';
export const SHOW_SEARCH_RESULTS = 'showSearchResults';
export const HIDE_SEARCH_RESULTS = 'hideSearchResults';
export const SHOW_PREVIEW = 'showPreview';
export const HIDE_PREVIEW = 'hidePreview';
export const HIDE_VARIANT_POPUP = 'hideVariantPopup';
export const CATEGORY_CLICKED = 'categoryClicked';
export const PICKER_HIDDEN = 'hidden';
