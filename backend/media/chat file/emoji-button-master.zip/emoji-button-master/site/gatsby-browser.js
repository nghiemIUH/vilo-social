import '@fortawesome/fontawesome-svg-core/styles.css';
import 'prismjs/themes/prism.css';
import './src/global.css';

import { config } from '@fortawesome/fontawesome-svg-core';

config.autoAddCss = false;
