import { EmojiButton } from '@joeattardi/emoji-button';

const picker = new EmojiButton({
  position: 'bottom-start'
});
