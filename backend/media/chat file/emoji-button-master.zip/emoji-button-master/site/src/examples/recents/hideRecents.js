import { EmojiButton } from '@joeattardi/emoji-button';

const picker = new EmojiPicker({
  showRecents: false
});
