import { EmojiButton } from '@joeattardi/emoji-button';

const picker = new EmojiButton({
  emojiSize: '64px',
  emojisPerRow: 4,
  rows: 4
});
