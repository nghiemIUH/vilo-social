import { EmojiButton } from '@joeattardi/emoji-button';
import frEmojiData from '@roderickhsiao/emoji-button-locale-data/dist/fr';

const picker = new EmojiButton({
  emojiData: frEmojiData
});
