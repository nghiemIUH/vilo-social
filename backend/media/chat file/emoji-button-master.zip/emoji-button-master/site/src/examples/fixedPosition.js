import { EmojiButton } from '@joeattardi/emoji-button';

const picker = new EmojiButton({
  position: {
    top: '0',
    right: '0'
  }
});
