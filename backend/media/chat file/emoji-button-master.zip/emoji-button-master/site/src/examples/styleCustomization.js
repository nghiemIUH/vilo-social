import { EmojiButton } from '@joeattardi/emoji-button';

const picker = new EmojiButton({
  styleProperties: {
    '--font': 'Courier New',
    '--category-button-color': 'red'
  }
});
